window.config = {
   "model_": "AppConfig",
   "id": 1,
   "appName": "Fullscreen Websit",
   "version": "1.0",
   "homepage": "https://chrome.google.com/webstore/detail/fullscreen-website/fokgfhnmolkgoadbhfmoihapdhkoofdm",
   "kioskEnabled": true
};